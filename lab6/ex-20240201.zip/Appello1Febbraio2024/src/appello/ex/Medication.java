package appello.ex;

public class Medication {
	// to be implemented
}
